import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Menu, X, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-background/95 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 md:px-12 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-primary text-primary-foreground p-2 rounded-lg group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
            <Leaf size={24} />
          </div>
          <span className={`font-serif font-bold text-xl tracking-tight ${scrolled ? 'text-foreground' : 'text-primary-foreground'} md:text-foreground`}>
            Agro Forte
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <a href="#manifesto" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Manifesto</a>
          <a href="#pilares" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Pilares</a>
          <a href="#tecnologia" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Tecnologia</a>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium rounded-full px-6">
            Junte-se ao Movimento
          </Button>
        </nav>

        <button 
          className="md:hidden text-foreground p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-background border-b border-border p-6 flex flex-col gap-4 shadow-lg">
          <a 
            href="#manifesto" 
            className="text-lg font-medium text-foreground py-2 border-b border-border/50"
            onClick={() => setMobileMenuOpen(false)}
          >
            Manifesto
          </a>
          <a 
            href="#pilares" 
            className="text-lg font-medium text-foreground py-2 border-b border-border/50"
            onClick={() => setMobileMenuOpen(false)}
          >
            Pilares
          </a>
          <a 
            href="#tecnologia" 
            className="text-lg font-medium text-foreground py-2 border-b border-border/50"
            onClick={() => setMobileMenuOpen(false)}
          >
            Tecnologia
          </a>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 mt-4 w-full rounded-full">
            Junte-se ao Movimento
          </Button>
        </div>
      )}
    </header>
  );
}
